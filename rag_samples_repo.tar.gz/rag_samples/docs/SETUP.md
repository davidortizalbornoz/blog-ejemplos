# 🛠️ Guía de Instalación - RAG Samples

## Requisitos Previos

### Software Requerido
- **Python 3.8+**
- **Docker** y **Docker Compose**
- **Git**
- **4GB+ RAM** disponible

### Verificar Instalaciones

```bash
# Python
python --version  # Debe ser 3.8+

# Docker
docker --version
docker-compose --version

# Git
git --version
```

---

## Instalación Paso a Paso

### 1. Clonar el Repositorio

```bash
git clone https://github.com/davidortizalbornoz/rag_samples.git
cd rag_samples
```

### 2. Crear Entorno Virtual (Recomendado)

```bash
# Crear entorno virtual
python -m venv venv

# Activar entorno virtual
# En Linux/Mac:
source venv/bin/activate

# En Windows:
venv\Scripts\activate
```

### 3. Instalar Dependencias Python

```bash
pip install --upgrade pip
pip install -r requirements.txt
```

---

## Configurar Weaviate

### Iniciar Weaviate con Docker

```bash
cd docker
docker-compose up -d
```

### Verificar que Weaviate está corriendo

```bash
# Verificar contenedores
docker-compose ps

# Verificar API
curl http://localhost:8080/v1/meta
```

Deberías ver información sobre el cluster de Weaviate.

### Detener Weaviate

```bash
docker-compose down
```

### Limpiar datos de Weaviate

```bash
docker-compose down -v
```

---

## Configurar Variables de Entorno

### 1. Copiar archivo de ejemplo

```bash
cp .env.example .env
```

### 2. Editar .env

```bash
# Editar con tu editor favorito
nano .env
# o
vim .env
# o
code .env
```

### 3. Configurar API Keys (Opcional)

Para usar ejemplos con LLMs reales, necesitas configurar API keys:

#### OpenAI

```bash
OPENAI_API_KEY=sk-your-api-key-here
```

Obtén tu API key en: https://platform.openai.com/api-keys

#### Anthropic (Claude)

```bash
ANTHROPIC_API_KEY=sk-ant-your-api-key-here
```

Obtén tu API key en: https://console.anthropic.com/

---

## Verificar Instalación

### Ejecutar Tests

```bash
pytest tests/
```

### Ejecutar Ejemplo Básico

```bash
python examples/01_basic_rag.py
```

Si todo funciona correctamente, verás:
- ✅ Conexión a Weaviate establecida
- ✅ Documentos indexados
- ✅ Respuestas generadas

---

## Troubleshooting

### Problema: No puedo conectar a Weaviate

**Solución:**

```bash
# Verificar que Docker está corriendo
docker info

# Verificar logs de Weaviate
cd docker
docker-compose logs weaviate

# Reiniciar Weaviate
docker-compose restart
```

### Problema: Puerto 8080 ocupado

**Solución:**

Edita `docker/docker-compose.yml`:

```yaml
ports:
  - "8081:8080"  # Cambiar puerto host
```

Luego actualiza `WEAVIATE_URL` en `.env`:

```bash
WEAVIATE_URL=http://localhost:8081
```

### Problema: Error al instalar paquetes Python

**Solución:**

```bash
# Actualizar pip
pip install --upgrade pip setuptools wheel

# Instalar con verbose
pip install -r requirements.txt -v
```

### Problema: Import errors

**Solución:**

```bash
# Instalar el paquete en modo desarrollo
pip install -e .
```

---

## Opciones de Modelos

### Modelo Inglés (Por defecto)

El `docker-compose.yml` por defecto usa `all-MiniLM-L6-v2` (rápido, solo inglés).

### Modelo Multiidioma (Para español)

Si tu contenido está en español u otros idiomas:

```bash
# Usar docker-compose multiidioma
cd docker
docker-compose -f docker-compose-multilingual.yml up -d
```

Este usa `paraphrase-multilingual-MiniLM-L12-v2` que soporta 50+ idiomas.

---

## Configuración Avanzada

### GPU Support

Si tienes GPU NVIDIA disponible:

Edita `docker/docker-compose.yml`:

```yaml
t2v-transformers:
  environment:
    ENABLE_CUDA: '1'  # Cambiar a 1
  deploy:
    resources:
      reservations:
        devices:
          - driver: nvidia
            count: 1
            capabilities: [gpu]
```

### Ajustar Chunk Size

En `.env`:

```bash
CHUNK_SIZE=1000      # Chunks más grandes
CHUNK_OVERLAP=100    # Mayor overlap
```

### Cambiar Número de Resultados

```bash
TOP_K=5  # Recuperar 5 documentos en lugar de 3
```

---

## Próximos Pasos

Una vez instalado:

1. ✅ Ejecuta `python examples/01_basic_rag.py`
2. ✅ Lee `docs/CONCEPTS.md` para entender RAG
3. ✅ Ejecuta `python examples/02_rag_with_openai.py` (con API key)
4. ✅ Adapta el código a tu caso de uso

---

## Recursos Adicionales

- [Documentación Weaviate](https://weaviate.io/developers/weaviate)
- [OpenAI API Docs](https://platform.openai.com/docs)
- [Docker Docs](https://docs.docker.com/)

---

## Soporte

¿Problemas con la instalación?

- 🐛 [Reportar Issue](https://github.com/davidortizalbornoz/rag_samples/issues)
- 💬 [Discusiones](https://github.com/davidortizalbornoz/rag_samples/discussions)
