# 🚀 Quick Start - RAG Samples

## Setup en 3 Pasos

### 1️⃣ Clonar e Instalar

```bash
git clone https://github.com/davidortizalbornoz/rag_samples.git
cd rag_samples
pip install -r requirements.txt
```

### 2️⃣ Iniciar Weaviate

```bash
cd docker
docker-compose up -d
cd ..
```

### 3️⃣ Ejecutar Ejemplo

```bash
python examples/01_basic_rag.py
```

---

## ¿Qué Hace Este Ejemplo?

1. **Indexa 8 documentos técnicos** sobre Docker, Kubernetes, Python, etc.
2. **Convierte texto a vectores** automáticamente con Weaviate
3. **Hace 3 preguntas** de prueba
4. **Busca documentos relevantes** por similitud semántica (KNN)
5. **Genera respuestas** basadas en los documentos encontrados

---

## Resultado Esperado

```
🔧 Initializing RAG pipeline...
✅ Connected to Weaviate at http://localhost:8080
✅ Retriever initialized (top_k=3)
✅ Using MockGenerator (no API key required)
✅ Document processor initialized
🚀 RAG pipeline ready!

📝 Indexing 8 documents...
   ✓ Docker - Contenedores: 2 chunks
   ✓ Kubernetes - Orquestación: 2 chunks
   ...
✅ Indexed 20 chunks from 8 documents

❓ Question: ¿Qué es Docker y para qué sirve?
🔍 Searching for relevant documents...
   Found 3 relevant documents
🤖 Generating answer...
✅ Answer generated

💬 Respuesta:
Docker es una plataforma de contenedores que permite empaquetar
aplicaciones con todas sus dependencias...
```

---

## Próximos Pasos

### Con API Key de OpenAI

```bash
# Configurar API key
export OPENAI_API_KEY=tu-api-key

# Ejecutar con GPT-4
python examples/02_rag_with_openai.py
```

### Indexar Tus Propios Documentos

```python
from src.rag_pipeline import RAGPipeline

rag = RAGPipeline()
rag.create_schema()

# Indexar tus documentos
rag.index_documents(
    documents=["Tu texto aquí..."],
    titles=["Tu título"]
)

# Hacer preguntas
result = rag.ask("Tu pregunta")
print(result["answer"])
```

---

## Comandos Útiles

```bash
# Detener Weaviate
docker-compose -f docker/docker-compose.yml down

# Limpiar datos
docker-compose -f docker/docker-compose.yml down -v

# Ver logs
docker-compose -f docker/docker-compose.yml logs -f

# Reiniciar
docker-compose -f docker/docker-compose.yml restart
```

---

## Documentación Completa

- **README.md**: Visión general del proyecto
- **docs/SETUP.md**: Guía de instalación detallada
- **docs/CONCEPTS.md**: Conceptos fundamentales de RAG

---

## Troubleshooting

### Weaviate no responde

```bash
# Verificar que está corriendo
docker ps

# Ver logs
docker-compose -f docker/docker-compose.yml logs weaviate
```

### Puerto ocupado

Edita `docker/docker-compose.yml` y cambia:
```yaml
ports:
  - "8081:8080"  # Usar puerto 8081
```

---

**¡Listo para empezar! 🎉**
