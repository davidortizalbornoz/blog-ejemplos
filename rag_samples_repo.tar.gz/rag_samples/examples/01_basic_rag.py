#!/usr/bin/env python3
"""
Example 1: Basic RAG without external LLM
Demonstrates retrieval and basic response generation
"""

import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from src.rag_pipeline import RAGPipeline


def main():
    print("=" * 70)
    print("  📚 EJEMPLO 1: RAG Básico (sin LLM externo)")
    print("=" * 70)
    print()
    print("Este ejemplo demuestra:")
    print("  ✓ Indexación de documentos en Weaviate")
    print("  ✓ Búsqueda semántica por similitud vectorial")
    print("  ✓ Generación básica de respuestas (sin API key)")
    print()
    
    # 1. Inicializar pipeline (sin LLM real)
    rag = RAGPipeline(
        class_name="BasicRAGExample",
        top_k=3,
        use_mock_generator=True  # No requiere API key
    )
    
    # 2. Crear schema
    rag.create_schema()
    
    # 3. Documentos de ejemplo sobre tecnología
    documents = [
        """
        Docker es una plataforma de contenedores que permite empaquetar aplicaciones
        con todas sus dependencias en un contenedor aislado. Los contenedores son
        ligeros, portables y garantizan que la aplicación funcionará igual en
        cualquier entorno. Docker usa imágenes para crear contenedores, y estas
        imágenes se pueden compartir en Docker Hub.
        """,
        """
        Kubernetes es un sistema de orquestación de contenedores que automatiza
        el despliegue, escalado y gestión de aplicaciones containerizadas. K8s
        (abreviatura de Kubernetes) trabaja con conceptos como Pods, Services,
        y Deployments. Un Pod es la unidad más pequeña en Kubernetes y puede
        contener uno o más contenedores.
        """,
        """
        Python es un lenguaje de programación de alto nivel, interpretado y de
        propósito general. Es conocido por su sintaxis clara y legible. Python
        es ampliamente usado en desarrollo web, ciencia de datos, machine learning
        y automatización. Para crear un entorno virtual en Python, usa el comando
        'python -m venv nombre_entorno'.
        """,
        """
        Weaviate es una base de datos vectorial open-source que permite almacenar
        objetos y vectores para realizar búsquedas semánticas. Los vectores son
        representaciones numéricas de datos que capturan el significado semántico.
        Weaviate usa estos vectores para encontrar objetos similares mediante
        búsqueda KNN (K-Nearest Neighbors).
        """,
        """
        RAG (Retrieval-Augmented Generation) es una técnica que combina búsqueda
        de información con generación de texto usando LLMs. Primero se buscan
        documentos relevantes en una base de datos vectorial, luego se usa un
        LLM para generar una respuesta basada en esos documentos. Esto reduce
        las alucinaciones y permite usar información actualizada.
        """,
        """
        Git es un sistema de control de versiones distribuido usado para rastrear
        cambios en código fuente durante el desarrollo de software. Comandos básicos
        incluyen: git init (inicializar repositorio), git add (añadir archivos),
        git commit (guardar cambios), git push (enviar a remoto), y git pull
        (obtener cambios del remoto).
        """,
        """
        REST API es un estilo de arquitectura para diseñar servicios web. REST
        usa métodos HTTP estándar: GET para obtener recursos, POST para crear,
        PUT para actualizar, y DELETE para eliminar. Los endpoints REST siguen
        una estructura jerárquica como /api/users/123. Las respuestas suelen ser
        en formato JSON.
        """,
        """
        PostgreSQL es un sistema de gestión de bases de datos relacional open-source.
        Soporta SQL avanzado, transacciones ACID, índices, y tipos de datos complejos.
        Para crear una base de datos: CREATE DATABASE nombre; Para conectarse:
        psql -U usuario -d nombre_db. PostgreSQL es conocido por su confiabilidad
        y cumplimiento de estándares.
        """
    ]
    
    titles = [
        "Docker - Contenedores",
        "Kubernetes - Orquestación",
        "Python - Lenguaje de Programación",
        "Weaviate - Base de Datos Vectorial",
        "RAG - Retrieval-Augmented Generation",
        "Git - Control de Versiones",
        "REST API - Arquitectura Web",
        "PostgreSQL - Base de Datos"
    ]
    
    # 4. Indexar documentos
    rag.index_documents(
        documents=documents,
        titles=titles
    )
    
    # 5. Hacer preguntas
    print("\n" + "=" * 70)
    print("  🔍 BÚSQUEDAS Y RESPUESTAS")
    print("=" * 70)
    
    questions = [
        "¿Qué es Docker y para qué sirve?",
        "¿Cómo puedo buscar información por significado en lugar de palabras exactas?",
        "Explícame qué es RAG y por qué es útil"
    ]
    
    for i, question in enumerate(questions, 1):
        print(f"\n{'─' * 70}")
        print(f"Pregunta {i}:")
        print("─" * 70)
        
        result = rag.ask(question)
        
        print(f"\n💬 Respuesta:\n")
        print(result["answer"])
        
        if result["sources"]:
            print(f"\n📚 Fuentes consultadas ({result['num_sources']}):")
            for j, source in enumerate(result["sources"], 1):
                print(f"\n   {j}. {source['title']}")
                print(f"      Relevancia: {source['certainty']:.2%}")
                print(f"      Vista previa: {source['content_preview'][:100]}...")
        
        input("\n⏸️  Presiona ENTER para continuar...")
    
    # 6. Estadísticas
    print(f"\n{'=' * 70}")
    print("  📊 ESTADÍSTICAS")
    print("=" * 70)
    
    stats = rag.get_stats()
    print(f"\nTotal de chunks indexados: {stats['total_documents']}")
    print(f"Weaviate URL: {stats['weaviate_url']}")
    print(f"Top K (documentos recuperados): {stats['top_k']}")
    print(f"Clase de Weaviate: {stats['class_name']}")
    
    print(f"\n{'=' * 70}")
    print("✅ Ejemplo completado!")
    print("=" * 70)
    
    print("""
💡 NOTA: Este ejemplo usa MockGenerator porque no tiene API key.
   Para usar un LLM real (GPT-4, Claude), configura tu API key:
   
   export OPENAI_API_KEY=tu-api-key
   # o en archivo .env
   
   Luego ejecuta: python examples/02_rag_with_openai.py
    """)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n👋 Interrumpido por el usuario")
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()
