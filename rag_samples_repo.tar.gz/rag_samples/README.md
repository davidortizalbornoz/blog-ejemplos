# 🧠 RAG Samples - Ejemplos de Retrieval-Augmented Generation

Repositorio con ejemplos prácticos de implementación de RAG (Retrieval-Augmented Generation) usando Weaviate y diferentes modelos de lenguaje.

## 📚 ¿Qué es RAG?

**RAG (Retrieval-Augmented Generation)** combina:
- **Retrieval**: Búsqueda de información relevante en base de datos vectorial
- **Augmented**: Enriquecimiento del contexto con esa información
- **Generation**: Generación de respuestas con LLM basadas en el contexto

### Ventajas de RAG:
✅ Información actualizada sin re-entrenar el modelo  
✅ Acceso a datos privados y específicos del dominio  
✅ Reducción significativa de alucinaciones  
✅ Respuestas verificables con fuentes citadas  
✅ Fácil actualización (solo añade documentos)  

---

## 🏗️ Arquitectura

```
┌──────────────┐
│  Documentos  │  PDFs, docs, web, DB, etc.
└──────┬───────┘
       │
       ↓
┌──────────────┐
│  Chunking    │  Dividir en trozos
└──────┬───────┘
       │
       ↓
┌──────────────┐
│  Embeddings  │  Texto → Vectores
└──────┬───────┘
       │
       ↓
┌──────────────┐
│  Weaviate    │  Base de datos vectorial
│  Vector DB   │
└──────────────┘

                     ┌──────────────┐
Usuario Pregunta ──→ │   Query      │
                     └──────┬───────┘
                            │
                            ↓
                     ┌──────────────┐
                     │  Search KNN  │  Búsqueda vectorial
                     └──────┬───────┘
                            │
                            ↓
                     ┌──────────────┐
                     │  Top K Docs  │  3-5 docs relevantes
                     └──────┬───────┘
                            │
                            ↓
                     ┌──────────────┐
                     │  Prompt +    │  Contexto enriquecido
                     │  Context     │
                     └──────┬───────┘
                            │
                            ↓
                     ┌──────────────┐
                     │     LLM      │  GPT-4, Claude, etc.
                     └──────┬───────┘
                            │
                            ↓
                     ┌──────────────┐
                     │   Response   │  Respuesta verificable
                     └──────────────┘
```

---

## 📁 Estructura del Proyecto

```
rag_samples/
├── README.md                    # Este archivo
├── requirements.txt             # Dependencias Python
├── .env.example                # Variables de entorno de ejemplo
│
├── docker/
│   ├── docker-compose.yml      # Weaviate con text2vec-transformers
│   └── docker-compose-multilingual.yml  # Weaviate multiidioma
│
├── examples/
│   ├── 01_basic_rag.py         # RAG básico sin LLM externo
│   ├── 02_rag_with_openai.py   # RAG completo con OpenAI
│   ├── 03_rag_with_sources.py  # RAG con citación de fuentes
│   ├── 04_streaming_rag.py     # RAG con respuestas streaming
│   └── 05_multimodal_rag.py    # RAG con texto e imágenes
│
├── notebooks/
│   ├── RAG_Tutorial.ipynb      # Tutorial interactivo
│   └── RAG_Performance.ipynb   # Análisis de rendimiento
│
├── src/
│   ├── __init__.py
│   ├── vectorstore.py          # Interfaz con Weaviate
│   ├── embeddings.py           # Manejo de embeddings
│   ├── retriever.py            # Lógica de recuperación
│   ├── generator.py            # Interfaz con LLMs
│   └── rag_pipeline.py         # Pipeline completo de RAG
│
├── data/
│   ├── sample_docs/            # Documentos de ejemplo
│   └── knowledge_base/         # Base de conocimiento
│
├── tests/
│   ├── test_vectorstore.py
│   ├── test_retriever.py
│   └── test_rag_pipeline.py
│
└── docs/
    ├── CONCEPTS.md             # Conceptos fundamentales
    ├── SETUP.md               # Guía de instalación
    └── EXAMPLES.md            # Guía de ejemplos
```

---

## 🚀 Inicio Rápido

### 1. Clonar el repositorio

```bash
git clone https://github.com/davidortizalbornoz/rag_samples.git
cd rag_samples
```

### 2. Instalar dependencias

```bash
pip install -r requirements.txt
```

### 3. Iniciar Weaviate

```bash
cd docker
docker-compose up -d
```

### 4. Ejecutar ejemplo básico

```bash
python examples/01_basic_rag.py
```

---

## 📦 Requisitos

### Software
- Python 3.8+
- Docker & Docker Compose
- 4GB+ RAM disponible

### Python Packages
- weaviate-client
- openai (opcional, para ejemplos con GPT)
- anthropic (opcional, para ejemplos con Claude)
- sentence-transformers (opcional, para embeddings locales)

---

## 🎯 Ejemplos Incluidos

### 1. RAG Básico (`01_basic_rag.py`)
- Indexación de documentos
- Búsqueda semántica
- Respuestas sin LLM externo
- **Ideal para**: Entender el concepto de retrieval

### 2. RAG con OpenAI (`02_rag_with_openai.py`)
- Pipeline completo con GPT-4
- Construcción de prompts
- Generación de respuestas
- **Ideal para**: Implementación en producción

### 3. RAG con Fuentes (`03_rag_with_sources.py`)
- Citación de fuentes
- Metadata tracking
- Respuestas verificables
- **Ideal para**: Aplicaciones empresariales

### 4. RAG Streaming (`04_streaming_rag.py`)
- Respuestas en tiempo real
- Experiencia de usuario mejorada
- Feedback inmediato
- **Ideal para**: Chatbots interactivos

### 5. RAG Multimodal (`05_multimodal_rag.py`)
- Texto + imágenes
- Búsqueda cross-modal
- Embeddings multimodales
- **Ideal para**: E-commerce, multimedia

---

## 🛠️ Configuración

### Variables de Entorno

Crea un archivo `.env` basado en `.env.example`:

```bash
# Weaviate
WEAVIATE_URL=http://localhost:8080

# OpenAI (opcional)
OPENAI_API_KEY=tu-api-key

# Anthropic (opcional)
ANTHROPIC_API_KEY=tu-api-key

# Configuración
CHUNK_SIZE=500
CHUNK_OVERLAP=50
TOP_K=3
```

---

## 📖 Casos de Uso

### 1. **Chatbot de Soporte Técnico**
```python
from src.rag_pipeline import RAGPipeline

# Indexar documentación
rag = RAGPipeline()
rag.index_documents("data/tech_docs/")

# Responder preguntas
answer = rag.ask("¿Cómo reseteo mi contraseña?")
```

### 2. **Asistente de Empresa**
```python
# Indexar políticas y manuales
rag.index_documents("data/company_policies/")

# Consultar información
answer = rag.ask("¿Cuál es la política de vacaciones?")
```

### 3. **Búsqueda en Documentación**
```python
# Indexar documentación técnica
rag.index_documents("data/api_docs/")

# Buscar información específica
answer = rag.ask("¿Cómo autenticar requests al API?")
```

---

## 🔧 API Reference

### RAGPipeline

```python
from src.rag_pipeline import RAGPipeline

# Inicializar
rag = RAGPipeline(
    weaviate_url="http://localhost:8080",
    openai_key="tu-api-key",
    top_k=3
)

# Indexar documentos
rag.index_documents(
    directory="data/docs/",
    chunk_size=500,
    chunk_overlap=50
)

# Hacer pregunta
answer = rag.ask(
    question="Tu pregunta aquí",
    include_sources=True,
    stream=False
)
```

---

## 📊 Rendimiento

### Benchmarks (Hardware: CPU moderna, sin GPU)

| Operación | Tiempo | Notas |
|-----------|--------|-------|
| Indexar 1K docs | ~30 seg | Con batch_size=100 |
| Búsqueda vectorial | ~15-20 ms | Top 3 resultados |
| Generación (GPT-4) | ~2-5 seg | Depende de longitud |
| Pipeline completo | ~3-6 seg | Retrieval + Generation |

---

## 🤝 Contribuir

¡Las contribuciones son bienvenidas!

1. Fork el proyecto
2. Crea una rama (`git checkout -b feature/AmazingFeature`)
3. Commit tus cambios (`git commit -m 'Add AmazingFeature'`)
4. Push a la rama (`git push origin feature/AmazingFeature`)
5. Abre un Pull Request

---

## 📝 Licencia

MIT License - ver archivo `LICENSE` para detalles.

---

## 🙏 Agradecimientos

- [Weaviate](https://weaviate.io/) - Base de datos vectorial open-source
- [OpenAI](https://openai.com/) - Modelos de lenguaje
- [Sentence Transformers](https://www.sbert.net/) - Modelos de embeddings

---

## 📚 Recursos Adicionales

- [Documentación de Weaviate](https://weaviate.io/developers/weaviate)
- [OpenAI API Docs](https://platform.openai.com/docs)
- [RAG Papers](https://arxiv.org/abs/2005.11401)

---

## 🆘 Soporte

¿Preguntas o problemas?

- 📧 Email: [tu-email]
- 🐛 Issues: [GitHub Issues](https://github.com/davidortizalbornoz/rag_samples/issues)
- 💬 Discussions: [GitHub Discussions](https://github.com/davidortizalbornoz/rag_samples/discussions)

---

**¡Feliz coding con RAG! 🚀**
