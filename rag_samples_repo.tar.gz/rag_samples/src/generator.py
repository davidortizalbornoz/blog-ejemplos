"""
Generator component for RAG pipeline
Interfaces with LLMs (OpenAI, Anthropic, etc.)
"""

from typing import Optional, Iterator, Dict, Any
import os


class LLMGenerator:
    """
    LLM interface for generating responses
    """
    
    def __init__(
        self,
        provider: str = "openai",
        model: str = "gpt-4",
        api_key: Optional[str] = None,
        temperature: float = 0.3
    ):
        """
        Initialize LLM generator
        
        Args:
            provider: LLM provider (openai, anthropic)
            model: Model name
            api_key: API key (or use env variable)
            temperature: Sampling temperature
        """
        self.provider = provider.lower()
        self.model = model
        self.temperature = temperature
        
        # Initialize provider
        if self.provider == "openai":
            import openai
            openai.api_key = api_key or os.getenv("OPENAI_API_KEY")
            self.client = openai
        elif self.provider == "anthropic":
            from anthropic import Anthropic
            self.client = Anthropic(api_key=api_key or os.getenv("ANTHROPIC_API_KEY"))
        else:
            raise ValueError(f"Unsupported provider: {provider}")
    
    def build_prompt(
        self,
        query: str,
        context: str,
        system_message: Optional[str] = None
    ) -> str:
        """
        Build prompt for LLM
        
        Args:
            query: User query
            context: Retrieved context
            system_message: Optional system message
            
        Returns:
            Formatted prompt
        """
        default_system = (
            "Eres un asistente experto. Responde las preguntas basándote "
            "ÚNICAMENTE en el contexto proporcionado. Si el contexto no "
            "contiene la información necesaria, di que no tienes suficiente "
            "información. Cita las fuentes cuando sea posible."
        )
        
        sys_msg = system_message or default_system
        
        prompt = f"""{sys_msg}

CONTEXTO:
{context}

PREGUNTA DEL USUARIO:
{query}

INSTRUCCIONES:
- Usa solo información del contexto
- Sé específico y claro
- Cita las fuentes (Documento 1, 2, etc.)
- Si no hay suficiente información, dilo claramente

RESPUESTA:"""
        
        return prompt
    
    def generate(
        self,
        query: str,
        context: str,
        system_message: Optional[str] = None,
        max_tokens: int = 1000
    ) -> str:
        """
        Generate response from LLM
        
        Args:
            query: User query
            context: Retrieved context
            system_message: Optional system message
            max_tokens: Maximum tokens to generate
            
        Returns:
            Generated response
        """
        prompt = self.build_prompt(query, context, system_message)
        
        if self.provider == "openai":
            response = self.client.ChatCompletion.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "Eres un asistente experto."},
                    {"role": "user", "content": prompt}
                ],
                temperature=self.temperature,
                max_tokens=max_tokens
            )
            return response.choices[0].message.content
        
        elif self.provider == "anthropic":
            message = self.client.messages.create(
                model=self.model,
                max_tokens=max_tokens,
                temperature=self.temperature,
                messages=[
                    {"role": "user", "content": prompt}
                ]
            )
            return message.content[0].text
    
    def generate_stream(
        self,
        query: str,
        context: str,
        system_message: Optional[str] = None,
        max_tokens: int = 1000
    ) -> Iterator[str]:
        """
        Generate streaming response
        
        Args:
            query: User query
            context: Retrieved context
            system_message: Optional system message
            max_tokens: Maximum tokens
            
        Yields:
            Response chunks
        """
        prompt = self.build_prompt(query, context, system_message)
        
        if self.provider == "openai":
            response = self.client.ChatCompletion.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "Eres un asistente experto."},
                    {"role": "user", "content": prompt}
                ],
                temperature=self.temperature,
                max_tokens=max_tokens,
                stream=True
            )
            
            for chunk in response:
                if chunk.choices[0].delta.get("content"):
                    yield chunk.choices[0].delta.content
        
        elif self.provider == "anthropic":
            with self.client.messages.stream(
                model=self.model,
                max_tokens=max_tokens,
                temperature=self.temperature,
                messages=[{"role": "user", "content": prompt}]
            ) as stream:
                for text in stream.text_stream:
                    yield text


class MockGenerator:
    """
    Mock generator for testing without API keys
    """
    
    def generate(
        self,
        query: str,
        context: str,
        system_message: Optional[str] = None,
        max_tokens: int = 1000
    ) -> str:
        """
        Generate mock response based on context
        
        Returns a formatted response using the context
        """
        # Extract first document content
        lines = context.split("\n")
        first_doc = []
        for line in lines:
            if line.startswith("Contenido:"):
                content = line.replace("Contenido:", "").strip()
                first_doc.append(content)
        
        if not first_doc:
            first_doc = ["[Contenido del contexto]"]
        
        response = f"""Basándome en la información proporcionada:

{first_doc[0][:300]}...

Esta información está basada en el contexto proporcionado. Para una respuesta
completa con un LLM real, configura tu API key de OpenAI o Anthropic.

[Esta es una respuesta simulada - MockGenerator]
"""
        return response
    
    def generate_stream(
        self,
        query: str,
        context: str,
        system_message: Optional[str] = None,
        max_tokens: int = 1000
    ) -> Iterator[str]:
        """Generate mock streaming response"""
        response = self.generate(query, context, system_message, max_tokens)
        # Simulate streaming by yielding words
        words = response.split()
        for word in words:
            yield word + " "
