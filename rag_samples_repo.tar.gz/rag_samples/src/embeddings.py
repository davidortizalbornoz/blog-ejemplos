"""
Embeddings utilities for document processing
"""

from typing import List, Dict, Any
import re


class TextChunker:
    """
    Splits text into chunks for embedding
    """
    
    def __init__(
        self,
        chunk_size: int = 500,
        chunk_overlap: int = 50,
        separator: str = "\n\n"
    ):
        """
        Initialize chunker
        
        Args:
            chunk_size: Target size of each chunk (characters)
            chunk_overlap: Overlap between chunks
            separator: Primary separator for splitting
        """
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.separator = separator
    
    def split_text(self, text: str) -> List[str]:
        """
        Split text into chunks
        
        Args:
            text: Input text
            
        Returns:
            List of text chunks
        """
        # First split by separator
        splits = text.split(self.separator)
        
        chunks = []
        current_chunk = ""
        
        for split in splits:
            # If split is empty, skip
            if not split.strip():
                continue
            
            # If adding this split doesn't exceed chunk size
            if len(current_chunk) + len(split) < self.chunk_size:
                current_chunk += split + self.separator
            else:
                # Save current chunk if not empty
                if current_chunk:
                    chunks.append(current_chunk.strip())
                
                # Start new chunk with overlap
                if chunks and self.chunk_overlap > 0:
                    # Get last N characters for overlap
                    overlap_text = current_chunk[-self.chunk_overlap:]
                    current_chunk = overlap_text + split + self.separator
                else:
                    current_chunk = split + self.separator
        
        # Add remaining chunk
        if current_chunk:
            chunks.append(current_chunk.strip())
        
        return chunks
    
    def chunk_document(
        self,
        content: str,
        metadata: Dict[str, Any]
    ) -> List[Dict[str, Any]]:
        """
        Chunk a document with metadata
        
        Args:
            content: Document content
            metadata: Document metadata
            
        Returns:
            List of chunk dictionaries
        """
        chunks = self.split_text(content)
        
        result = []
        for i, chunk in enumerate(chunks):
            chunk_dict = {
                "content": chunk,
                "chunk_id": i,
                **metadata
            }
            result.append(chunk_dict)
        
        return result


class DocumentProcessor:
    """
    Process documents from various formats
    """
    
    def __init__(self, chunker: TextChunker):
        """
        Initialize processor
        
        Args:
            chunker: TextChunker instance
        """
        self.chunker = chunker
    
    def process_text(
        self,
        text: str,
        title: str = "Untitled",
        source: str = "text",
        metadata: Optional[Dict] = None
    ) -> List[Dict[str, Any]]:
        """
        Process plain text
        
        Args:
            text: Input text
            title: Document title
            source: Document source
            metadata: Additional metadata
            
        Returns:
            List of document chunks
        """
        # Clean text
        text = self.clean_text(text)
        
        # Build metadata
        doc_metadata = {
            "title": title,
            "source": source,
            **(metadata or {})
        }
        
        # Chunk document
        chunks = self.chunker.chunk_document(text, doc_metadata)
        
        return chunks
    
    def process_file(
        self,
        file_path: str,
        metadata: Optional[Dict] = None
    ) -> List[Dict[str, Any]]:
        """
        Process file (txt, md)
        
        Args:
            file_path: Path to file
            metadata: Additional metadata
            
        Returns:
            List of document chunks
        """
        import os
        
        # Read file
        with open(file_path, 'r', encoding='utf-8') as f:
            text = f.read()
        
        # Extract title from filename
        title = os.path.basename(file_path)
        
        return self.process_text(
            text=text,
            title=title,
            source=file_path,
            metadata=metadata
        )
    
    def clean_text(self, text: str) -> str:
        """
        Clean and normalize text
        
        Args:
            text: Input text
            
        Returns:
            Cleaned text
        """
        # Remove multiple newlines
        text = re.sub(r'\n{3,}', '\n\n', text)
        
        # Remove multiple spaces
        text = re.sub(r' {2,}', ' ', text)
        
        # Remove leading/trailing whitespace
        text = text.strip()
        
        return text
