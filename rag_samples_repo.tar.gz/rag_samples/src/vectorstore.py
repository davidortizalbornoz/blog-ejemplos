"""
Vector Store implementation using Weaviate
"""

import weaviate
from typing import List, Dict, Optional, Any
from datetime import datetime


class WeaviateVectorStore:
    """
    Wrapper for Weaviate vector database
    """
    
    def __init__(
        self,
        url: str = "http://localhost:8080",
        api_key: Optional[str] = None,
        class_name: str = "Document"
    ):
        """
        Initialize Weaviate client
        
        Args:
            url: Weaviate instance URL
            api_key: Optional API key for authentication
            class_name: Name of the Weaviate class to use
        """
        self.url = url
        self.class_name = class_name
        
        # Connect to Weaviate
        if api_key:
            self.client = weaviate.Client(
                url=url,
                auth_client_secret=weaviate.AuthApiKey(api_key=api_key)
            )
        else:
            self.client = weaviate.Client(url=url)
        
        # Verify connection
        if not self.client.is_ready():
            raise ConnectionError(f"Cannot connect to Weaviate at {url}")
    
    def create_schema(self, properties: Optional[List[Dict]] = None):
        """
        Create schema for document storage
        
        Args:
            properties: Optional custom properties
        """
        # Delete existing class if exists
        try:
            self.client.schema.delete_class(self.class_name)
        except:
            pass
        
        # Default properties
        default_properties = [
            {
                "name": "content",
                "dataType": ["text"],
                "description": "Document content"
            },
            {
                "name": "title",
                "dataType": ["string"],
                "description": "Document title"
            },
            {
                "name": "source",
                "dataType": ["string"],
                "description": "Document source"
            },
            {
                "name": "chunk_id",
                "dataType": ["int"],
                "description": "Chunk index"
            },
            {
                "name": "metadata",
                "dataType": ["string"],
                "description": "Additional metadata as JSON string"
            },
            {
                "name": "timestamp",
                "dataType": ["date"],
                "description": "Creation timestamp"
            }
        ]
        
        # Use custom properties if provided
        props = properties or default_properties
        
        # Create schema
        schema = {
            "class": self.class_name,
            "description": "Document storage for RAG",
            "vectorizer": "text2vec-transformers",
            "moduleConfig": {
                "text2vec-transformers": {
                    "vectorizeClassName": False
                }
            },
            "properties": props
        }
        
        self.client.schema.create_class(schema)
        print(f"✅ Schema '{self.class_name}' created successfully")
    
    def add_documents(
        self,
        documents: List[Dict[str, Any]],
        batch_size: int = 100
    ) -> int:
        """
        Add documents to vector store
        
        Args:
            documents: List of document dictionaries
            batch_size: Batch size for insertion
            
        Returns:
            Number of documents added
        """
        count = 0
        
        with self.client.batch as batch:
            batch.batch_size = batch_size
            
            for doc in documents:
                # Add timestamp if not present
                if "timestamp" not in doc:
                    doc["timestamp"] = datetime.now().isoformat() + "Z"
                
                # Add to batch
                batch.add_data_object(
                    data_object=doc,
                    class_name=self.class_name
                )
                count += 1
        
        print(f"✅ Added {count} documents to Weaviate")
        return count
    
    def search(
        self,
        query: str,
        limit: int = 3,
        filters: Optional[Dict] = None,
        include_vector: bool = False
    ) -> List[Dict[str, Any]]:
        """
        Semantic search using near_text
        
        Args:
            query: Search query
            limit: Number of results to return
            filters: Optional WHERE filters
            include_vector: Whether to include vectors in results
            
        Returns:
            List of documents with scores
        """
        # Build query
        additional = ["distance", "certainty"]
        if include_vector:
            additional.append("vector")
        
        query_builder = (
            self.client.query
            .get(self.class_name, ["content", "title", "source", "chunk_id", "metadata"])
            .with_near_text({"concepts": [query]})
            .with_limit(limit)
            .with_additional(additional)
        )
        
        # Add filters if provided
        if filters:
            query_builder = query_builder.with_where(filters)
        
        # Execute query
        result = query_builder.do()
        
        # Extract results
        if "data" in result and "Get" in result["data"]:
            docs = result["data"]["Get"][self.class_name]
            return docs
        
        return []
    
    def search_by_vector(
        self,
        vector: List[float],
        limit: int = 3,
        filters: Optional[Dict] = None
    ) -> List[Dict[str, Any]]:
        """
        Search using vector directly
        
        Args:
            vector: Query vector
            limit: Number of results
            filters: Optional filters
            
        Returns:
            List of documents
        """
        query_builder = (
            self.client.query
            .get(self.class_name, ["content", "title", "source", "chunk_id"])
            .with_near_vector({"vector": vector})
            .with_limit(limit)
            .with_additional(["distance", "certainty"])
        )
        
        if filters:
            query_builder = query_builder.with_where(filters)
        
        result = query_builder.do()
        
        if "data" in result and "Get" in result["data"]:
            return result["data"]["Get"][self.class_name]
        
        return []
    
    def delete_all(self):
        """Delete all documents"""
        try:
            self.client.schema.delete_class(self.class_name)
            print(f"✅ All documents deleted from '{self.class_name}'")
        except Exception as e:
            print(f"⚠️  Error deleting documents: {e}")
    
    def count_documents(self) -> int:
        """
        Count total documents
        
        Returns:
            Number of documents
        """
        result = (
            self.client.query
            .aggregate(self.class_name)
            .with_meta_count()
            .do()
        )
        
        if "data" in result and "Aggregate" in result["data"]:
            return result["data"]["Aggregate"][self.class_name][0]["meta"]["count"]
        
        return 0
    
    def get_by_id(self, doc_id: str) -> Optional[Dict[str, Any]]:
        """
        Get document by ID
        
        Args:
            doc_id: Document UUID
            
        Returns:
            Document dict or None
        """
        try:
            return self.client.data_object.get_by_id(
                doc_id,
                class_name=self.class_name
            )
        except Exception:
            return None
