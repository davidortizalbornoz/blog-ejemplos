"""
Retriever component for RAG pipeline
"""

from typing import List, Dict, Any, Optional
from .vectorstore import WeaviateVectorStore


class VectorRetriever:
    """
    Handles document retrieval from vector store
    """
    
    def __init__(
        self,
        vectorstore: WeaviateVectorStore,
        top_k: int = 3,
        score_threshold: float = 0.7
    ):
        """
        Initialize retriever
        
        Args:
            vectorstore: WeaviateVectorStore instance
            top_k: Number of documents to retrieve
            score_threshold: Minimum certainty score (0-1)
        """
        self.vectorstore = vectorstore
        self.top_k = top_k
        self.score_threshold = score_threshold
    
    def retrieve(
        self,
        query: str,
        filters: Optional[Dict] = None,
        top_k: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """
        Retrieve relevant documents for query
        
        Args:
            query: User query
            filters: Optional metadata filters
            top_k: Override default top_k
            
        Returns:
            List of relevant documents with scores
        """
        k = top_k or self.top_k
        
        # Search in vector store
        results = self.vectorstore.search(
            query=query,
            limit=k * 2,  # Get more results to filter
            filters=filters
        )
        
        # Filter by score threshold
        filtered_results = [
            doc for doc in results
            if doc["_additional"]["certainty"] >= self.score_threshold
        ]
        
        # Return top k
        return filtered_results[:k]
    
    def retrieve_with_reranking(
        self,
        query: str,
        filters: Optional[Dict] = None,
        top_k: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """
        Retrieve with basic reranking (can be extended with cross-encoder)
        
        Args:
            query: User query
            filters: Optional filters
            top_k: Override default top_k
            
        Returns:
            Reranked documents
        """
        # Get initial results
        results = self.retrieve(query, filters, top_k)
        
        # Simple reranking: prioritize by certainty and content length
        def rerank_score(doc):
            certainty = doc["_additional"]["certainty"]
            # Prefer longer, more detailed documents
            content_len_score = min(len(doc["content"]) / 1000, 1.0)
            return certainty * 0.7 + content_len_score * 0.3
        
        results.sort(key=rerank_score, reverse=True)
        
        return results
    
    def format_results_for_context(
        self,
        results: List[Dict[str, Any]],
        include_sources: bool = True
    ) -> str:
        """
        Format retrieved documents for LLM context
        
        Args:
            results: Retrieved documents
            include_sources: Whether to include source information
            
        Returns:
            Formatted context string
        """
        context_parts = []
        
        for i, doc in enumerate(results, 1):
            part = f"Documento {i}:\n"
            
            if "title" in doc and doc["title"]:
                part += f"Título: {doc['title']}\n"
            
            part += f"Contenido: {doc['content']}\n"
            
            if include_sources:
                certainty = doc["_additional"]["certainty"]
                part += f"Relevancia: {certainty:.2%}\n"
                
                if "source" in doc and doc["source"]:
                    part += f"Fuente: {doc['source']}\n"
            
            context_parts.append(part)
        
        return "\n\n".join(context_parts)
    
    def get_sources(
        self,
        results: List[Dict[str, Any]]
    ) -> List[Dict[str, str]]:
        """
        Extract source information from results
        
        Args:
            results: Retrieved documents
            
        Returns:
            List of source dictionaries
        """
        sources = []
        
        for doc in results:
            source_info = {
                "title": doc.get("title", "Unknown"),
                "source": doc.get("source", "Unknown"),
                "certainty": doc["_additional"]["certainty"],
                "content_preview": doc["content"][:200] + "..."
            }
            sources.append(source_info)
        
        return sources
