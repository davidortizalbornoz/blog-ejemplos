"""
Complete RAG Pipeline
Integrates vectorstore, retriever, and generator
"""

from typing import List, Dict, Any, Optional, Iterator
import os
from dotenv import load_dotenv

from .vectorstore import WeaviateVectorStore
from .retriever import VectorRetriever
from .generator import LLMGenerator, MockGenerator
from .embeddings import TextChunker, DocumentProcessor


# Load environment variables
load_dotenv()


class RAGPipeline:
    """
    Complete RAG (Retrieval-Augmented Generation) pipeline
    """
    
    def __init__(
        self,
        weaviate_url: Optional[str] = None,
        openai_key: Optional[str] = None,
        class_name: str = "Document",
        top_k: int = 3,
        chunk_size: int = 500,
        chunk_overlap: int = 50,
        use_mock_generator: bool = False
    ):
        """
        Initialize RAG pipeline
        
        Args:
            weaviate_url: Weaviate instance URL
            openai_key: OpenAI API key
            class_name: Weaviate class name
            top_k: Number of documents to retrieve
            chunk_size: Size of text chunks
            chunk_overlap: Overlap between chunks
            use_mock_generator: Use mock generator instead of real LLM
        """
        # Get configuration from env if not provided
        self.weaviate_url = weaviate_url or os.getenv("WEAVIATE_URL", "http://localhost:8080")
        self.openai_key = openai_key or os.getenv("OPENAI_API_KEY")
        self.top_k = top_k
        
        # Initialize components
        print("🔧 Initializing RAG pipeline...")
        
        # 1. Vector store
        self.vectorstore = WeaviateVectorStore(
            url=self.weaviate_url,
            class_name=class_name
        )
        print(f"✅ Connected to Weaviate at {self.weaviate_url}")
        
        # 2. Retriever
        self.retriever = VectorRetriever(
            vectorstore=self.vectorstore,
            top_k=top_k
        )
        print(f"✅ Retriever initialized (top_k={top_k})")
        
        # 3. Generator
        if use_mock_generator or not self.openai_key:
            self.generator = MockGenerator()
            print("✅ Using MockGenerator (no API key required)")
        else:
            self.generator = LLMGenerator(
                provider="openai",
                api_key=self.openai_key
            )
            print("✅ LLM Generator initialized (OpenAI)")
        
        # 4. Document processor
        self.chunker = TextChunker(
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap
        )
        self.processor = DocumentProcessor(chunker=self.chunker)
        print("✅ Document processor initialized")
        
        print("🚀 RAG pipeline ready!\n")
    
    def create_schema(self):
        """Create or recreate Weaviate schema"""
        self.vectorstore.create_schema()
    
    def index_documents(
        self,
        documents: List[str],
        titles: Optional[List[str]] = None,
        sources: Optional[List[str]] = None,
        metadata: Optional[List[Dict]] = None
    ) -> int:
        """
        Index documents into vector store
        
        Args:
            documents: List of document texts
            titles: Optional titles for each document
            sources: Optional sources for each document
            metadata: Optional metadata for each document
            
        Returns:
            Number of chunks indexed
        """
        print(f"\n📝 Indexing {len(documents)} documents...")
        
        all_chunks = []
        
        for i, doc in enumerate(documents):
            title = titles[i] if titles else f"Document {i+1}"
            source = sources[i] if sources else f"doc_{i+1}"
            meta = metadata[i] if metadata else {}
            
            # Process document
            chunks = self.processor.process_text(
                text=doc,
                title=title,
                source=source,
                metadata=meta
            )
            
            all_chunks.extend(chunks)
            print(f"   ✓ {title}: {len(chunks)} chunks")
        
        # Add to vector store
        count = self.vectorstore.add_documents(all_chunks)
        print(f"\n✅ Indexed {count} chunks from {len(documents)} documents\n")
        
        return count
    
    def index_files(
        self,
        file_paths: List[str],
        metadata: Optional[List[Dict]] = None
    ) -> int:
        """
        Index documents from files
        
        Args:
            file_paths: List of file paths
            metadata: Optional metadata for each file
            
        Returns:
            Number of chunks indexed
        """
        print(f"\n📁 Indexing {len(file_paths)} files...")
        
        all_chunks = []
        
        for i, file_path in enumerate(file_paths):
            meta = metadata[i] if metadata else {}
            
            # Process file
            chunks = self.processor.process_file(file_path, meta)
            all_chunks.extend(chunks)
            
            print(f"   ✓ {file_path}: {len(chunks)} chunks")
        
        # Add to vector store
        count = self.vectorstore.add_documents(all_chunks)
        print(f"\n✅ Indexed {count} chunks from {len(file_paths)} files\n")
        
        return count
    
    def ask(
        self,
        question: str,
        include_sources: bool = True,
        filters: Optional[Dict] = None,
        system_message: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Ask a question using RAG
        
        Args:
            question: User question
            include_sources: Whether to include source information
            filters: Optional metadata filters
            system_message: Optional system message for LLM
            
        Returns:
            Dictionary with answer and sources
        """
        print(f"\n❓ Question: {question}")
        
        # 1. Retrieve relevant documents
        print(f"🔍 Searching for relevant documents...")
        relevant_docs = self.retriever.retrieve(
            query=question,
            filters=filters
        )
        
        if not relevant_docs:
            return {
                "answer": "No encontré información relevante para responder tu pregunta.",
                "sources": [],
                "num_sources": 0
            }
        
        print(f"   Found {len(relevant_docs)} relevant documents")
        
        # 2. Format context
        context = self.retriever.format_results_for_context(
            results=relevant_docs,
            include_sources=include_sources
        )
        
        # 3. Generate answer
        print(f"🤖 Generating answer...")
        answer = self.generator.generate(
            query=question,
            context=context,
            system_message=system_message
        )
        
        # 4. Extract sources
        sources = self.retriever.get_sources(relevant_docs) if include_sources else []
        
        result = {
            "answer": answer,
            "sources": sources,
            "num_sources": len(sources)
        }
        
        print(f"✅ Answer generated\n")
        
        return result
    
    def ask_stream(
        self,
        question: str,
        include_sources: bool = True,
        filters: Optional[Dict] = None,
        system_message: Optional[str] = None
    ) -> Iterator[str]:
        """
        Ask a question with streaming response
        
        Args:
            question: User question
            include_sources: Whether to include sources
            filters: Optional filters
            system_message: Optional system message
            
        Yields:
            Response chunks
        """
        print(f"\n❓ Question: {question}")
        
        # Retrieve documents
        print(f"🔍 Searching...")
        relevant_docs = self.retriever.retrieve(
            query=question,
            filters=filters
        )
        
        if not relevant_docs:
            yield "No encontré información relevante para responder tu pregunta."
            return
        
        print(f"   Found {len(relevant_docs)} documents")
        
        # Format context
        context = self.retriever.format_results_for_context(
            results=relevant_docs,
            include_sources=include_sources
        )
        
        # Generate streaming
        print(f"🤖 Generating (streaming)...\n")
        for chunk in self.generator.generate_stream(
            query=question,
            context=context,
            system_message=system_message
        ):
            yield chunk
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Get pipeline statistics
        
        Returns:
            Statistics dictionary
        """
        return {
            "total_documents": self.vectorstore.count_documents(),
            "weaviate_url": self.weaviate_url,
            "top_k": self.top_k,
            "class_name": self.vectorstore.class_name
        }
